public class Bus implements Vehicle {
	public void travel(){
		System.out.println("get on the bus and take a seat!");
	}
}