public class FactoryTest {
	
	public static void main(String args[]) {
		VehicleFactory vehiclFactory = new VehicleFactory();
		
		Vehicle vehicle1 = vehiclFactory.getVehicle("car");
		vehicle1.travel();
		
		Vehicle vehicle2 = vehiclFactory.getVehicle("bus");
		vehicle2.travel();
		
		Vehicle vehicle3 = vehiclFactory.getVehicle("train");
		vehicle3.travel();
	}
}