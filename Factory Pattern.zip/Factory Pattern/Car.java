public class Car implements Vehicle {
	public void travel(){
		System.out.println("get into the car and just drive!");
	}
}