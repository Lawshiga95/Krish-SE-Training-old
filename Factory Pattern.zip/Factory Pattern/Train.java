public class Train implements Vehicle {
	public void travel(){
		System.out.println("get on the train and find your seat!");
	}
}