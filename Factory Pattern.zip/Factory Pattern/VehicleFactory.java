public class VehicleFactory {
	
	public Vehicle getVehicle(String type){
		if(type == null) {
			return null;
		}
		if(type.equalsIgnoreCase("car")) {
			return new Car();
		} else if(type.equalsIgnoreCase("Bus")) {
			return new Bus();
		} else if(type.equalsIgnoreCase("train")) {
			return new Train();
		}
		return null;
	}
}