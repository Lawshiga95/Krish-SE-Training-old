public interface Vehicle {
	void travel();
}