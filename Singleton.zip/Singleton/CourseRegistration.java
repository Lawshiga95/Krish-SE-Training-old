public class CourseRegistration {
	private static volatile CourseRegistration courseRegistration;
	
	private CourseRegistration(){}
	
	public static CourseRegistration getCourseRegistration(){
		if(courseRegistration == null) {
			synchronized(CourseRegistration.class){
				if(courseRegistration == null) {
					courseRegistration = new CourseRegistration();
				}
			}
		}
		return courseRegistration;
	}
	
}