public class CourseRegistrationDemo {
	public static void main(String args[]) {
		CourseRegistration newRegister = CourseRegistration.getCourseRegistration();
		System.out.println(newRegister);
		
		CourseRegistration newRegister1 = CourseRegistration.getCourseRegistration();
		System.out.println(newRegister1);
		
		
	}
}