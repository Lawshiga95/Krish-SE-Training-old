
public class IllegalDepositException extends Exception{
	public IllegalDepositException (String msg) {
		super(msg);
	}
}

