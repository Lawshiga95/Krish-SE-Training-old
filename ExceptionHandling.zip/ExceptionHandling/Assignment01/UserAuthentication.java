class User {
	public User(){		
	}
}

public class UserAuthentication {
	
	public User authenticate(String userId) throws UserNotFoundException{
		if(userId.equals("1234")) {
			return new User();
		} else {
			throw new UserNotFoundException("invalid userId " + userId);
		}
}
}