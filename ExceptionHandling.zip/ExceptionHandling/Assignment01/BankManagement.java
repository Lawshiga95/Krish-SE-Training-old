
public class BankManagement {
	public static void main(String args[]) {
		
		UserAuthentication user = new UserAuthentication();
		try{
			user.authenticate("1245");			
			
		} catch(UserNotFoundException exc) {
			System.err.println(exc);
		}
		
		Deposit deposit = new Deposit();
		try{
			deposit.depositMoney(0);
			
		} catch(IllegalDepositException exc) {
			System.err.println(exc);
		}
	}
	
}



