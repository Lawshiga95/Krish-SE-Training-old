 import java.io.*;

public class CheckedExceptionExample{
	public static void main(String args[]) throws IOException {
		
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		
		try{
		 fileReader = new FileReader("C:\text.txt");
		} catch(FileNotFoundException exc){
			System.out.println("This file does not exit or not found :" + exc);
		}
		try{
		 bufferedReader = new BufferedReader(fileReader);	
			for(int i=0; i<10; i++) {
				System.out.println(bufferedReader.readLine());
			}
		} catch(IOException exc) {
			System.out.println("I/O error occurred :" + exc);	
		}
		
		}
		
	}
