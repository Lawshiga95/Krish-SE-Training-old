import java.io.*;

public class UnCheckedExceptionExample {
	public static void main(String args[]){
		int a = 10; 
		int b = 0;
		try {
			
			int c = a/b;
		}
		catch(IllegalCalculationException exc) {
			System.err.println("Division by zero is not allowed " + exc);
		}
	}
}