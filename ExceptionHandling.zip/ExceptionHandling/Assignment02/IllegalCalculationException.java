
public class IllegalCalculationException extends RuntimeException{
	public IllegalCalculationException (String msg) {
		super(msg);
	}
}

