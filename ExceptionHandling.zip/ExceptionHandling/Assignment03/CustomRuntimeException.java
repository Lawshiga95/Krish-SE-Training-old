
public class CustomRuntimeException extends RuntimeException{
	public CustomRuntimeException (String msg) {
		super(msg);
	}
}

